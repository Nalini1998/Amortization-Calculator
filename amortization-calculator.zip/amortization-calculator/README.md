# Amortization Calculator

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/qBQGNbg/94dc20d486cd32e12a417ab00c2e1068](https://codepen.io/Nalini1998/pen/qBQGNbg/94dc20d486cd32e12a417ab00c2e1068).

